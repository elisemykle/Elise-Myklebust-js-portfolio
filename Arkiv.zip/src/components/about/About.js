import React from 'react';

function About() {
    return (
        <h1>ABOUT ME...</h1>
    );
}

export default About;
