import React from 'react';

function Cv() {
    return (
        <h1>CV - My Experiences</h1>
    );
}

export default Cv;
